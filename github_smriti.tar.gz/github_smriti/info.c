#include <stdio.h>
int main()
{
	printf("Name:Thanush L \n");
	printf("\t\t\tDepartment:EEE \n");
	printf("\t\t\t\t\t\t\tCollege:CMRIT \n");
}



