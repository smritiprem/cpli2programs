#include <stdio.h>
int main()
{
	float num1,num2,sum,sub,multiply,divide;
	num1=10;
	num2=20;
	sum=num1+num2;
	sub=num1-num2;
	multiply=num1*num2;
	divide=num1/num2;
	printf("Answer is %f \n",sum);
	printf("Answer is %f \n",sub);
	printf("Answer is %f \n",multiply);
	printf("Answer is %f \n",divide);
	return 0;
}

