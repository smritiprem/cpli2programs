#include <stdio.h>
int main()
{
	int num1,num2,sum;
	num1=10;
	num2=20;
	sum=num1+num2;
	printf("Answer is % d",sum);
	return 0;
}

